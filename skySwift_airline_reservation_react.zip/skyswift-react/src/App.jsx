import React from 'react'
import { NavLink, Routes, Route } from 'react-router-dom'
import Home from './pages/Home.jsx'
import Search from './pages/Search.jsx'
import Results from './pages/Results.jsx'
import Book from './pages/Book.jsx'
import Confirm from './pages/Confirm.jsx'
import Manage from './pages/Manage.jsx'
import Checkin from './pages/Checkin.jsx'
import Admin from './pages/Admin.jsx'

export default function App(){
  return (
    <>
      <header className="nav">
        <div className="brand">✈️ SkySwift</div>
        <nav>
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/search">Book</NavLink>
          <NavLink to="/manage">Manage</NavLink>
          <NavLink to="/checkin">Check-in (DCS)</NavLink>
          <NavLink to="/admin">Admin</NavLink>
        </nav>
      </header>
      <main className="container">
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/search" element={<Search/>}/>
          <Route path="/results" element={<Results/>}/>
          <Route path="/book" element={<Book/>}/>
          <Route path="/confirm" element={<Confirm/>}/>
          <Route path="/manage" element={<Manage/>}/>
          <Route path="/checkin" element={<Checkin/>}/>
          <Route path="/admin" element={<Admin/>}/>
        </Routes>
      </main>
      <footer className="footer">
        <div><strong>Core:</strong> CRS, Inventory, DCS, Payment, Fare Mgmt.</div>
        <div><strong>Modules:</strong> Passenger & Admin • <strong>Post-booking:</strong> PNR, Ancillaries, Ticketing, Sync (simulated)</div>
      </footer>
    </>
  )
}
